/* =========================================
    GUIDE SPA SYSTEM

    ���� ����

    1?? DOM �غ�
    2?? restoreStatus() �� localStorage ���� ����
    3?? statusManager.init() �� �ؽ�Ʈ + ī��Ʈ ���
    4?? loadInitial() �� ù ȭ�� �ε�
========================================= */
$(document).ready(function () {
    /* =========================================
        1. ���� ����
    ========================================= */
    function restoreStatus() {
        $(".component-item").each(function () {
            const $item = $(this);
            const file = $item.find(".component-info").data("include-path");

            // !file üũ ���� : include-path ���� ��� ����, ���� �ڵ�, �������� ���� ����
            if (!file) return;

            const name = file.split("/").pop().replace(".html", "");

            const saved = localStorage.getItem("guide_status_" + name);

            if (saved) {
                $item.removeClass("non ing comp");
                $item.addClass(saved);
            }
        });
    }

    /* ===============================
        2. ������Ʈ �ε�
    =============================== */

    function loadComponent($el) {

        if (!$el.length) return;

        const file = $el.data("include-path");
        if (!file) return;

        // active ó��
        $(".component-info").removeClass("active");
        $el.addClass("active");

        // HTML �ε�
        $("#component-view").load(file, function () {

            // ���ϸ� �������� init ����
            const name = file
                .split("/")
                .pop()
                .replace(".html", "");

            runComponentInit(name);
            bindStatusControl(name);
        });

        // URL hash ����
        const hashName = file
            .split("/")
            .pop()
            .replace(".html", "");

        window.location.hash = hashName;
    }

    /* =========================================
        3. ���� ��ư -> ���̵� �޴� �ݿ�
    ========================================= */
    function bindStatusControl(componentName) {
        const $activeMenu = $(".component-info.active").closest(".component-item");
        if (!$activeMenu.length) return;

        $(".status-btn").off("click").on("click", function () {
            // ���� ���� Ŭ���� ����
            $activeMenu.removeClass("non ing comp");

            // ���� ����
            let state = "";

            // ��ư ���� Ȯ��
            if ($(this).hasClass("todo")) {
                $activeMenu.addClass("non");
                state = "non";
            } else if ($(this).hasClass("inprogress")) {
                $activeMenu.addClass("ing");
                state = "ing";
            } else if ($(this).hasClass("completed")) {
                $activeMenu.addClass("comp");
                state = "comp";
            }

            // ���� ������Ʈ �̸� ����
            const file = $activeMenu.find(".component-info").data("include-path");

            const name = file.split("/").pop().replace(".html", "");

            // ���� ����
            localStorage.setItem("guide_status_" + name, state);

            // statusManager�� ��ü ����
            if (typeof statusManager !== "undefined") {
                statusManager.update();
            }
        })
    }

    /* ===============================
        4. ù ȭ�� �ڵ� �ε�
    =============================== */

    function loadInitial() {

        const hash = window.location.hash.replace("#", "");

        if (hash) {
            const $target = $(".component-info").filter(function () {
                return $(this)
                    .data("include-path")
                    .toLowerCase()
                    .includes(hash.toLowerCase());
            });

            if ($target.length) {
                loadComponent($target.first());
                return;
            }
        }

        // �⺻ ù ��°
        loadComponent($(".component-info").first());
    }

    /* ===============================
        5. �޴� Ŭ��
    =============================== */

    $(".component-info").on("click", function (e) {
        e.preventDefault();
        loadComponent($(this));
    });

    /* ===============================
        6. �ʱ� ���� ����
    =============================== */

    restoreStatus(); // ���� ����

    if (typeof statusManager !== "undefined") {
        statusManager.init(); // �� ���� ���
    }

    loadInitial(); // ȭ�� �ε�

    // �̸����� �� ��ȯ
    if (typeof initPreviewTabs === "function") {
        initPreviewTabs();
    }

    /* ===============================
        7. �ڷΰ��� ����
    =============================== */

    $(window).on("hashchange", function () {
        loadInitial();
    });
})

/* =========================================
    Component Init Auto Mapping
========================================= */

function runComponentInit(name) {

    if (!name) return;

    // kebab-case -> PascalCase ��ȯ
    const pascal = name.toLowerCase().split("-").map(word => word.charAt(0).toUpperCase() + word.slice(1)).join("");

    const fnName = "init" + pascal;

    if (typeof window[fnName] === "function") {
        window[fnName]();
    }
}


